from django.apps import AppConfig


class BookcollectionConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'bookcollection'
