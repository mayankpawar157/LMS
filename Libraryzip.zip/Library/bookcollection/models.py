from datetime import datetime
from django.db import models

from useraccount.models import Student
   
    
class Author(models.Model):
    name = models.CharField(max_length=50)
    bio = models.TextField() 
    def __str__(self):
        return self.name   
    
class Book(models.Model):
    title = models.CharField(max_length=50) 
    author = models.ForeignKey(Author, on_delete=models.CASCADE)   
    description = models.TextField( null=True, blank=True)
    published_year = models.DateField(null=True, blank=True)
    image = models.ImageField(upload_to='media')
    AVAILABILITY_CHOICES = (
        ('Available', 'Available'),
        ('Borrowed', 'Borrowed'),
  
    )

    availability_status = models.CharField(
        max_length=10,
        choices=AVAILABILITY_CHOICES,
        default='available',  # You can set the default status as 'available'
    )
    
    def __str__(self):
        return self.title
    
    
class BorrowBook(models.Model):
    user = models.ForeignKey(Student, on_delete=models.CASCADE)
    book = models.ForeignKey(Book, on_delete=models.CASCADE)
    borrow = models.DateField(auto_now=True) 
    returns = models.BooleanField(default=False) 

    def is_return(self):
        self.borrow = datetime.now()
        self.returns = True
        self.save()
        