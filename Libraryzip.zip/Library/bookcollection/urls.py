from django.urls import path
from .views import about, author_show, book_show, borrow_book, borrow_failure, borrow_history, borrow_success, contact, delete, detail, return_book, status, student_show, update

urlpatterns = [
    
    path('author/', author_show, name='author'),
    path('book/', book_show, name='book'),
    path('student/', student_show, name='student'),
    path('detail/<int:id>/', detail, name='detail'),
    path('update/<int:id>/', update, name='update'),
    path('delete/<int:id>/', delete, name='delete'),
    path('status/<int:id>/', status, name='status'),
    path('borrow/<int:id>/', borrow_book, name='borrow'),
    path('about/', about, name='about'),
    path('borrow_success/', borrow_success, name='borrow_success'),
    path('borrow_failure/', borrow_failure, name='borrow_failure'),
    path('contact/', contact, name='contact'),
    path('borrow_history/', borrow_history, name='borrow_history'),
    path('return_book/<int:id>/', return_book, name='return_book')
    
]