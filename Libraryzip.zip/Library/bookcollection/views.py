from pyexpat.errors import messages
from django.shortcuts import render, redirect, get_object_or_404

from useraccount.models import Student
from django.contrib.auth.decorators import login_required

from .forms import  BookForm
from .models import Author, Book, BorrowBook

@login_required(login_url='login')
def author_show(request):
    data = Author.objects.all()
    return render(request, 'bookcollection/author.html', {"data":data})

@login_required(login_url='login')
def book_show(request):
    data = Book.objects.all()
    return render(request, 'bookcollection/book.html', {"data":data})

@login_required(login_url='login')
def student_show(request):
    data = Student.objects.all()
    return render(request, 'bookcollection/student.html', {"data":data})

@login_required(login_url='login')
def detail(request, id):
    data = Book.objects.get(id=id)
    return render(request, 'bookcollection/detail.html', {"data":data})

@login_required(login_url='login')
def update(request, id):
    data = get_object_or_404(Book, id=id)
    form  = BookForm(request.POST or None, instance=data)
    if form.is_valid():
        form.save()
        return redirect('home')
    return (request, 'bookcollection/update.html', {"form":form})

@login_required(login_url='login')
def delete(request, id):
    data = get_object_or_404(Book, id=id)
    if request.methode == "POST":
        data.delete()
        return redirect('home')
    
    return render(request, 'bookcollection/delete.html', {"data":data})

@login_required(login_url='login')
def status(request, id):
    try: 
        data = Book.objects.get(id=id)
    except Book.DoesNotExist:
        return render(request, 'status.html')
        
    context = {"data":data}
    return render(request, 'bookcollection/status.html', context)

@login_required(login_url='login')
def borrow_book(request, id):
    book = Book.objects.get(id=id)
    if book.availability_status == 'Available':
        book.availability_status = 'Borrowed'
        book.save()
        list = BorrowBook(user = request.user, book = book)
        list.save()
        return redirect(borrow_success)
    else:
        return redirect(borrow_failure)
    
    return render(request, 'bookcollection/borrow_book.html', {"book":book})



@login_required(login_url='login')
def borrow_success(request):
    return render(request, 'bookcollection/borrow_success.html')

@login_required(login_url='login')
def borrow_failure(request):
    return render(request, 'bookcollection/borrow_failure.html')
  

@login_required(login_url='login')
def about(request):
    return render(request, 'bookcollection/about.html') 

@login_required(login_url='login')
def contact(request):
    return render(request, 'bookcollection/contact.html') 

@login_required(login_url='login')
def borrow_history(request):
    data = BorrowBook.objects.all()
    return render(request, 'bookcollection/history.html', {"data":data})

@login_required(login_url='login')
def return_book(request, id):
    entry = get_object_or_404(BorrowBook, id=id)
    if entry.returns:
        return render(request, 'bookcollection/return_book.html')
    
    else:
        borrowed_book = entry.book
        borrowed_book.availability_status = 'Available'
        borrowed_book.save()

        entry.returns = True
        entry.save()

        return redirect('borrow_history')