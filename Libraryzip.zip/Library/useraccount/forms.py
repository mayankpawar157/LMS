from django import forms
from .models import Student
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm

class SignupForm(UserCreationForm):
    class Meta:
        models = Student
        fields = ('username', 'password', 'email')
        
class loginForm(AuthenticationForm):
    class Meta:
        model = Student