
from django.shortcuts import render, redirect
from django.contrib.auth import login, logout, authenticate

# from .forms import SignupForm, loginForm
from .models import Student

def home(request):
    return render(request, 'useraccount/home.html')

def signup(request):
    if request.method == "POST":
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']
        
        user = Student.objects.create_user(username=username, email=email, password=password)
        login(request, user)
        return redirect(user_login)
    return render(request, 'useraccount/signup.html')

def user_login(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        print(username, password)
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect(home)
        else:
            print("invalid credential")
    return render(request, 'useraccount/login.html')
 

def user_logout(request):
    logout(request)
    return render(request, 'useraccount/logout.html')